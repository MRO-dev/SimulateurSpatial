This zip file contains some data files useful for
use with the orekit library (http://www.orekit.org/).

In order to use this file, simply put it anywhere you
want and add its absolute path to the orekit.data.path
java property. There is no need to unzip the file, Orekit
will read directly into the zip.

This zip file contains JPL DE 406 ephemerides from 1962
to 2029, IERS Earth orientation parameters from 1962
to 2009 (both IAU-1980 and IAU-2000), UTC-TAI history
from 1972 to 2009 and the Eigen 05C gravity field.
